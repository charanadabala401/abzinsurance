package com.school.dao;


import java.util.ArrayList;

import com.school.bean.UserBean;

/**
 * @author:Charan,Priyatham,Gnaneshwar,Mayuresh
 * UserDao interface
 * It consists of all the abstract methods
 */
public interface UserDAO {
	
	public ArrayList<Integer> login(UserBean u);
	public String forgot(UserBean u);
public String AddUsers(UserBean u);
ArrayList<UserBean> ViewallUsers();

}
