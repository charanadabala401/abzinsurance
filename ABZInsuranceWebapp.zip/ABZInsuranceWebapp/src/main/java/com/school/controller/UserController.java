package com.school.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;


/**
 * @author:Charan,Priyatham,Gnaneshwar,Mayuresh
 * User Controller Servlet
 * used to login to the application
 */
public class UserController extends HttpServlet {
	
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	private static final long serialVersionUID = 1L;
       
   
    public UserController() {
        super();
     
    }


	/* @author:Charan,Priyatham,Gnaneshwar,Mayuresh
	 * User Controller dopost()
	 * Common Privilage to both User and Admin
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		UserBean u = new UserBean();
		UserDAOImpl userDAO = new UserDAOImpl();
	
		u.setUserName(request.getParameter("uname"));
		u.setPassWord(request.getParameter("pass"));
		ArrayList<Integer> list= userDAO.login(u);
//		System.out.println(list);
		int type=0;
		try{
			if(list!=null)
			{
				try {
					type=list.get(0);
				} catch (IndexOutOfBoundsException e) {
				
					//e.printStackTrace();
					out.println("Invalid User Name/Password");
					RequestDispatcher rd = request.getRequestDispatcher("signin.jsp");
					rd.include(request, response);	
				}
				int userId=list.get(1);
				HttpSession session=request.getSession(true);
				session.setAttribute("uid", userId);
			}else{
				out.println("Invalid User Name/ Password");
			}
		
		
		
		if(type==0)
		{
			out.println("Please Enter Valid User Name / Password");
			RequestDispatcher rd = request.getRequestDispatcher("signin.jsp");
			rd.include(request, response);	
		}if(type==1){
			RequestDispatcher rd = request.getRequestDispatcher("AdminHome.jsp");
			rd.forward(request, response);
			
			
		}else if(type==2){
			RequestDispatcher rd = request.getRequestDispatcher("UserHome.jsp");
			rd.forward(request, response);

		}
		else{
			out.println("Please Enter Valid User Name / Password");
			RequestDispatcher rd = request.getRequestDispatcher("signin.jsp");
			rd.include(request, response);
		}
		}
	  catch(IndexOutOfBoundsException i){
		  i.printStackTrace();
		  logger.info("UserController IndexOutOfBoundsException");
	  }
		logger.info(u.type+" type try to login into the application:"+u.getUserName());  //in method
	}

}
