package com.school.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;
import com.school.db.ConnectionManager;


/**
 * @author:Charan,Priyatham,Gnaneshwar,Mayuresh
 *Update User Servlet
 *Used to change the EmailId of Existing User
 */
public class UpdateUser extends HttpServlet {
	
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	private static final long serialVersionUID = 1L;
    public UpdateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	/* @author:Charan,Priyatham,Gnaneshwar,Mayuresh
	 * Update User doPost()
	 * user privilage
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		Connection con = ConnectionManager.getConnection();
		try {
			con.setAutoCommit(false);
		} catch (SQLException e) {

			logger.info("UpdateUser SQLException");       //in method

			e.printStackTrace();
		}
		if(con!=null)
		{
			}
		else
		{}
		
		try {
			PreparedStatement ps = con.prepareStatement("Update `insurance`.`users` set email=? where user_id=? and role_id=2" );

			ps.setInt(2,Integer.parseInt(request.getParameter("id")));
			ps.setString(1,request.getParameter("email"));
         int b = ps.executeUpdate();
			con.commit();	
			//System.out.println("iiiiiiiiiiiiiii"+b+request.getParameter("id")+"\\\\\\\\\\"+request.getParameter("email"));
			 if(b==1)
				{request.setAttribute("message", "update succes");
				RequestDispatcher rd=request.getRequestDispatcher("Update1.jsp");
				rd.forward(request, response);
					
				}
				else
				{
					request.setAttribute("message", "failed to update");
					RequestDispatcher rd=request.getRequestDispatcher("Update1.jsp");
					rd.forward(request, response);
				}
					 
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UpdateUser SQLException");       //in method

			e.printStackTrace();
		}
		UserBean u=new UserBean();
		logger.info("User type try to Update Email in the application:"+u.getUserName());  //in method  
		  

	}

}
