package com.school.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.dao.UserDAO;
import com.school.db.ConnectionManager;

/**
 * @author:Charan,Priyatham,Gnaneshwar,Mayuresh
 *UserDaoImpl Class
 *It Consists of all the implementations of abstract methods in UserDao Interface
 */
public class UserDAOImpl implements UserDAO {
	static Logger logger=Logger.getLogger(UserDAOImpl.class);
	/* @author:Charan,Priyatham,Gnaneshwar,Mayuresh
	 * DaoImpl login method
	 *  Common functionality for both user and admin
	 */
	public ArrayList<Integer> login(UserBean u) {
		int type=0;
		int userId=0;
		ArrayList<Integer> list=null;
		try {
			Connection con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from `insurance`.`users` where first_name=? AND password=?");
			ps.setString(1, u.getUserName());
			ps.setString(2, u.getPassWord());
			list=new ArrayList<Integer>();
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				type=rs.getInt(5);
				userId=rs.getInt(1);
				list.add(type);
				list.add(userId);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");
			e.printStackTrace();
			
		}
		logger.info("User Type try to login into the application:"+type);
		return list;
	}

	/**
	 * @author:Charan,Priyatham,Gnaneshwar,Mayuresh
	 * Daoimpl forgot method
	 * Common functionality for both user and admin
	 */
	public String forgot(UserBean u) {
		
		String password=null;
		try {
			Connection con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement("select password from `insurance`.`users` where first_name=? AND question =? AND answer=?");
            ps.setString(1, u.getUserName());
			ps.setString(2, u.getQuestion());
			ps.setString(3, u.getAnswer());
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				password=rs.getString(1);
			System.out.println("password---->"+password);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");
			e.printStackTrace();
		}
		logger.info("User Type Forgot Password in the application:"+u.getUserName());

		return password;
	}
	/* @author:Charan,Priyatham,Gnaneshwar,Mayuresh
	 * DaoImpl AddUsers method
	 * user privilage
	 */
	public String AddUsers(UserBean u)
	{
		

		String status="";
		Connection con = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("insert into insurance.users(first_name,email,password,role_id,mobile_number,address,question,answer) values (?,?,?,2,?,?,?,?)");
		ps.setString(1, u.getUserName());
		ps.setString(2, u.getEmailId());
		ps.setString(3, u.getPassWord());
		ps.setLong(4, u.getMobileNo());
		ps.setString(5, u.getAddress());
		ps.setString(6, u.getQuestion());
		ps.setString(7, u.getAnswer());
		int i=ps.executeUpdate();
	//	con.commit();
		System.out.println("jhcdbjbvndb "+i);
		if(i==1)
		{ status="Success";}
		else
		{status="not Success";}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");

			e.printStackTrace();
		}
		logger.info("User Type try to Add New User "+u.getUserName());
		
		return status;
		
	}
	/* @author:Charan,Priyatham,Gnaneshwar,Mayuresh
	 * DaoImpl ViewallUsers method
	 * Admin Privilage
	 * 
	 */
	public ArrayList<UserBean> ViewallUsers() {
		
		Connection con = ConnectionManager.getConnection();
		ArrayList<UserBean> al=new ArrayList<UserBean>();
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `insurance`.`users`");
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				UserBean ub=new UserBean();
			ub.setUserId(rs.getInt(1));
			ub.setUserName(rs.getString(2));
			al.add(ub);
				}
			System.out.println("---------------"+al);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");

			e.printStackTrace();
		}
		logger.info("Admin Type try  to ViewAll Users in the application");
		return al;
	}

}
